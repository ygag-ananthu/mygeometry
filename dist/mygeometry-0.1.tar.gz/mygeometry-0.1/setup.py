from setuptools import setup, find_packages

setup(
    name='mygeometry',
    version='0.1',
    description='A simple Python library for calculating the area of geometric shapes.',
    author='Ananthu',
    packages=find_packages(),
)