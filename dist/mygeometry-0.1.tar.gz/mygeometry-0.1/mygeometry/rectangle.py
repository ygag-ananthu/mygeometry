def rectangle_area(length, width):
    return length * width